"""
Aurora Premium 极光主题插件
高端液态玻璃风格，深色石墨 + 金色点缀，亮/暗双模式
"""

from typing import Dict, Any

from ...sdk.theme_base import (
    ThemePluginBase,
    ThemeConfig,
    ThemeColors,
    ThemeTypography,
    ThemeLayout,
    ThemeEffects,
)
from ...sdk.base import PluginMeta


class Plugin(ThemePluginBase):
    """
    @brief Aurora Premium 极光主题插件入口
    @details 构建基于 Liquid Glass 设计风格的高端主题配置
    """

    def __init__(self, meta: PluginMeta, config: Dict[str, Any]):
        super().__init__(meta, config)
        self._accent = config.get("accent_color", "#CA8A04")
        self._dark_mode = config.get("dark_mode", "auto")
        self._glass = config.get("glass_effect", True)
        self._custom_font = config.get("custom_font", True)

    def get_all_themes(self) -> Dict[str, ThemeConfig]:
        """
        @brief 构建 Aurora Premium 多主题配置
        @return Dict[str, ThemeConfig] 包含多种色系的主题变体
        """
        themes = {}
        themes["default"] = self._build_theme("default", "极光金 (默认)", self._accent, "#D97706")
        themes["ocean"] = self._build_theme("ocean", "深海蓝", "#2563EB", "#1E40AF")
        themes["cyber"] = self._build_theme("cyber", "赛博紫", "#9333EA", "#6B21A8")
        themes["forest"] = self._build_theme("forest", "暗影绿", "#16A34A", "#15803D")
        return themes

    def _build_theme(self, tid: str, name: str, accent: str, gradient_end: str) -> ThemeConfig:
        ## 亮色模式色板
        light_colors = ThemeColors(
            primary="#1C1917",
            primary_hover="#292524",
            secondary="#78716C",
            accent=accent,
            background="#FAFAF9",
            surface="#FFFFFF",
            surface_hover="#F5F5F4",
            text_primary="#0C0A09",
            text_secondary="#57534E",
            text_muted="#A8A29E",
            border="#E7E5E4",
            divider="#F5F5F4",
            success="#16A34A",
            warning="#CA8A04",
            error="#DC2626",
            info="#2563EB",
            gradient_start=accent,
            gradient_end=gradient_end,
        )

        ## 暗色模式色板
        dark_colors = ThemeColors(
            primary="#FAFAF9",
            primary_hover="#E7E5E4",
            secondary="#A8A29E",
            accent=accent,
            background="#0C0A09",
            surface="#1C1917",
            surface_hover="#292524",
            text_primary="#FAFAF9",
            text_secondary="#D6D3D1",
            text_muted="#78716C",
            border="#292524",
            divider="#1C1917",
            success="#22C55E",
            warning="#EAB308",
            error="#EF4444",
            info="#3B82F6",
            gradient_start=accent,
            gradient_end=gradient_end,
        )

        ## 字体配置
        if self._custom_font:
            typography = ThemeTypography(
                heading_font="'Cormorant', 'Noto Serif SC', Georgia, serif",
                body_font="'Montserrat', 'Noto Sans SC', -apple-system, sans-serif",
                mono_font="'JetBrains Mono', 'Fira Code', Consolas, monospace",
                font_import_url="https://fonts.googleapis.com/css2?family=Cormorant:wght@400;500;600;700&family=Montserrat:wght@300;400;500;600;700&family=Noto+Sans+SC:wght@300;400;500;700&family=Noto+Serif+SC:wght@400;600;700&display=swap",
                base_size=14,
                heading_weight=600,
            )
        else:
            typography = ThemeTypography(
                heading_font="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
                body_font="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
                base_size=14,
                heading_weight=600,
            )

        ## 布局配置
        layout = ThemeLayout(
            border_radius=12,
            border_radius_lg=16,
            border_radius_sm=6,
            header_height=64,
            content_max_width=1280,
        )

        ## 特效配置
        if self._glass:
            effects = ThemeEffects(
                shadow_sm="0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04)",
                shadow_md="0 4px 12px rgba(0,0,0,0.08), 0 2px 4px rgba(0,0,0,0.04)",
                shadow_lg="0 12px 24px rgba(0,0,0,0.1), 0 4px 8px rgba(0,0,0,0.04)",
                shadow_xl="0 24px 48px rgba(0,0,0,0.12), 0 8px 16px rgba(0,0,0,0.06)",
                backdrop_blur="blur(16px) saturate(180%)",
                transition_duration="250ms",
                transition_timing="cubic-bezier(0.4, 0, 0.2, 1)",
                glass_bg="rgba(255,255,255,0.72)",
                glass_border="rgba(255,255,255,0.2)",
            )
        else:
            effects = ThemeEffects(
                shadow_sm="0 1px 2px rgba(0,0,0,0.05)",
                shadow_md="0 4px 6px rgba(0,0,0,0.08)",
                shadow_lg="0 10px 15px rgba(0,0,0,0.1)",
                shadow_xl="0 20px 25px rgba(0,0,0,0.12)",
                backdrop_blur="none",
                transition_duration="200ms",
                transition_timing="ease",
                glass_bg="rgba(255,255,255,0.95)",
                glass_border="rgba(0,0,0,0.06)",
            )

        return ThemeConfig(
            id=tid,
            name=name,
            mode=self._dark_mode,
            colors=light_colors,
            dark_colors=dark_colors,
            typography=typography,
            layout=layout,
            effects=effects,
        )

    @staticmethod
    def _lighten_hex(hex_color: str, percent: int) -> str:
        """
        @brief 将十六进制颜色变亮指定百分比
        @param hex_color 原始颜色 (#RRGGBB)
        @param percent 变亮百分比 (0-100)
        @return 变亮后的颜色
        """
        hex_color = hex_color.lstrip("#")
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)

        r = min(255, r + int((255 - r) * percent / 100))
        g = min(255, g + int((255 - g) * percent / 100))
        b = min(255, b + int((255 - b) * percent / 100))

        return f"#{r:02x}{g:02x}{b:02x}"
